<?PHP

$host = "mysql3.amenworld.com:3306";
$user = "my50060";
$password = "unzc0pbu";
$dbname = "my50060";



?>