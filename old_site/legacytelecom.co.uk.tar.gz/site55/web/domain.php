<?php

global $authDomain;
$authDomain = "legacy";
?>
 