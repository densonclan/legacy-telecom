// JavaScript Document
function openSurvey(survey){



window.open(survey,"","width=100,height,100,left=0,top=0,location=no,toolbar=no,resizable=no,scrollbars=yes");

}