<?php

require_once ("../authentication.php");

header("Location: http://www.lan.co.uk/unauthorised.htm");
?>


 