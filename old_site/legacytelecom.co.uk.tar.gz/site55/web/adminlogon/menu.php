<?PHP

echo "<tr><td colspan=20><a href=\"http://d2l.lan.co.uk/LT/LTpages.php?new=true\">new</a> | <a href=\"http://d2l.lan.co.uk/LT/LTpages.php?existing=true\">existing</a> | <a href=\"http://www.legacytelecom.co.uk/adminlogon/editFAQ.php\">FAQ</a> | <a href=\"http://d2l.lan.co.uk/LT/upload.php\">upload a file</a> | <a href=\"http://www.legacytelecom.co.uk/adminlogon/editMembers.php\">site members</a> | <a href=\"http://www.legacytelecom.co.uk/adminlogon/editSurveys.php\">surveys</a></td></tr>";

?>
